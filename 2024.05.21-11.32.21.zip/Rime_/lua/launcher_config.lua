-- 默认应用启动或切换触发前缀为"jj"
-- 可在下行配置其他的触发前缀
local appLaunchPrefix = "vc" -- 修改应用启动切换触发词jj
local favorCmdPrefix = "vv" -- 修改快捷指令触发词ofk

local commands = {
    -- 应用启动切换
    ["Windows"] = {
        ["/jcm"] = { "CMD", "cmd.exe" },
        ["/jdn"] = { "Explorer", "::{20D04FE0-3AEA-1069-A2D8-08002B30309D}" },
        ["/jec"] = { "Excel", "excel.exe" },
        ["/jwd"] = { "Word", "word.exe" },
        ["/jht"] = { "画图", "mspaint.exe" },
        ["/jjs"] = { "计算器", "calc.exe" },
    },
    ["MacOS"] = {
        ["/jjt"] = { "截图", "com.apple.screenshot.launcher" },
        ["/jss"] = { "截图", "com.apple.screenshot.launcher" },
        ["/jam"] = { "任务监视器", "com.apple.ActivityMonitor" },
        ["/jtm"] = { "任务监视器", "com.apple.ActivityMonitor" },
        ["/jsp"] = { "系统设置", "com.apple.systempreferences" },
        ["/jfl"] = { "ForkLift", "com.binarynights.ForkLift-3" },
        ["/jpf"] = { "PathFinder", "com.cocoatech.PathFinder" },
        ["/jfd"] = { "Finder", "com.apple.finder" },
        ["/jsf"] = { "Safari 浏览器", "com.apple.Safari" },
        ["/jgc"] = { "Chrome 浏览器", "com.google.Chrome" },
        ["/jch"] = { "Chrome 浏览器", "com.google.Chrome" },
        ["/jff"] = { "Firefox 浏览器", "org.mozilla.firefox" },
        ["/jed"] = {
            { "Edge 浏览器", "com.microsoft.edgemac" },
            { "Eudic", "com.eusoft.eudic" },
        },
        ["/jfy"] = { "Eudic", "com.eusoft.eudic" },
        ["/jol"] = { "Outlook 邮箱", "com.microsoft.Outlook" },
        ["/jwm"] = { "网易云音乐", "com.netease.163music" },
        ["/jnm"] = { "网易云音乐", "com.netease.163music" },
        ["/jqw"] = { "企业微信", "com.tencent.WeWorkMac" },
        ["/jww"] = { "企业微信", "com.tencent.WeWorkMac" },
        ["/jwx"] = { "微信", "com.tencent.xinWeChat" },
        ["/jwc"] = { "微信", "com.tencent.xinWeChat" },
        ["/jqq"] = { "QQ", "com.tencent.qq" },
        ["/jnv"] = { "Neovide", "com.neovide.neovide" },
        ["/jvc"] = { "VSCode", "com.microsoft.VSCode" },
        ["/job"] = { "Obsidian", "md.obsidian" },
        ["/jat"] = { "alacritty 终端", "org.alacritty" },
        ["/jit"] = { "iTerm2 终端", "com.googlecode.iterm2" },
        ["/jdl"] = { "FDM 下载", "org.freedownloadmanager.fdm6" },
    },
    ["iOS"] = {},

	-- 快捷指令〔邮箱账号, 书签网址, 各种卡号(手机/银行卡/身份证), 文件夹位置〕
	-- [中括号]里的为索引键，最好不要带「空 格」字符
	-- [action]里的为执行动作，"commit"为字符上屏，"open"为打开对象
	-- 动作名称"commit/open"，不能更改
	["Favors"] = {
		-- [中括号]里的为索引键, 最好不要带「空 格」字符
		-- [action]里的为执行动作, "commit" 为字符上屏, "open" 为打开对象
		-- 动作名称"commit/open", 不能更改
		["m邮箱1"] = {
			["action"] = "commit",
			["items"] = {
				"a",
			},
		},
		["t电话2"] = {
			["action"] = "commit",
			["items"] = {
				["a联通1"] = "1",
			},
		},
		["c卡号3"] = {
			["action"] = "commit",
			["items"] = {
				["a身份证11"] = "2",
				["b身份证22"] = "3",
			},
		},
		["p码表4"] = {
			["action"] = "commit",
			["items"] = {
				["a码1"] = "o",
			},
		},
		["a地址5"] = {
			["action"] = "commit",
			["items"] = {
				["a园11"] = "园",
			},
		},
		["b书签6"] = {
			["action"] = "open",
			["items"] = {
				["rime-ice仓库6"] = "https://github.com/iDvel/rime-ice",
				["rime-fast-xhup仓库7"] = "https://github.com/boomker/rime-fast-xhup",
				["Hamster仓库8"] = "https://github.com/imfuxiao/Hamster",
			},
		},
		["f路径7"] = {
			["action"] = "open",
			["items"] = {
				["微信备份5"] = "~/Documents",
			},
		},
		["i终端8"] = {
			["action"] = "exec",
			["items"] = {
				["暗黑模式开关3"] =
				"osascript -e 'tell application \"System Events\" to tell appearance preferences to set dark mode to not dark mode'",
				["立即熄屏4"] = "pmset displaysleepnow",
				["开启屏保5"] = "/System/Library/CoreServices/ScreenSaverEngine.app/Contents/MacOS/ScreenSaverEngine",
				["刷新DNS缓存6"] = "dscacheutil -flushcache",
				["Rime部署7"] = "/Library/Input Methods/Squirrel.app/Contents/MacOS/squirrel --reload",
				["Rime同步8"] = "/Library/Input Methods/Squirrel.app/Contents/MacOS/Squirrel --sync",
				["隐藏桌面图标9"] = "defaults write com.apple.finder CreateDesktop false && killall Finder",
				["显示桌面图标10"] = "defaults write com.apple.finder CreateDesktop true && killall Finder",
			},
		},
	},
}

return { appLaunchPrefix, favorCmdPrefix, commands }
