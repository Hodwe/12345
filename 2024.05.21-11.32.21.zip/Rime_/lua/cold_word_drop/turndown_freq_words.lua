local turndown_freq_words =
{ ["示~例~"] = { "shili", },
}
return turndown_freq_words
