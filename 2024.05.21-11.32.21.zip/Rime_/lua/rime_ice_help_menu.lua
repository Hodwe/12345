﻿-- helper.lua
-- List features and usage of the schema.

local function translator(input, seg, env)
    local composition = env.engine.context.composition
    local segment = composition:back()
    if seg:has_tag("rime_ice_help") or (input == "vhe") or (input == "vhelp") then
        local table = {
            { '帮助菜单', '→ vhe键引导' },
        }
        segment.prompt = '〔简要说明〕'
        for _, v in ipairs(table) do
            local cand = Candidate('help', seg.start, seg._end, v[1], ' ' .. v[2])
            cand.quality = 999
            yield(cand)
        end
    end
end

return { translator = translator }
